package com.example.pro_dialer

import android.content.Intent
import android.telecom.Call
import android.telecom.InCallService
import android.telecom.VideoProfile
import android.util.Log

class CallService : InCallService() {

    companion object {
        private const val TAG = "CallService"
        
        // Singleton instance to access the service from Flutter/MainActivity
        private var instance: CallService? = null
        
        // Current active call
        private var currentCall: Call? = null
        
        // Public getter for the current call
        fun getCurrentCall(): Call? = currentCall
        
        // Answer the current call
        fun answer() {
            currentCall?.let { call ->
                Log.d(TAG, "Answering call")
                call.answer(VideoProfile.STATE_AUDIO_ONLY)
            } ?: run {
                Log.w(TAG, "No active call to answer")
            }
        }
        
        // Hang up the current call
        fun hangup() {
            currentCall?.let { call ->
                Log.d(TAG, "Hanging up call")
                call.disconnect()
            } ?: run {
                Log.w(TAG, "No active call to hang up")
            }
        }
        
        // Mute/unmute the call
        fun setMuted(muted: Boolean) {
            currentCall?.let { call ->
                Log.d(TAG, "Setting mute to: $muted")
                // Note: Mute state is managed through the system
            } ?: run {
                Log.w(TAG, "No active call to mute")
            }
        }
        
        // Check if there's an active call
        fun hasActiveCall(): Boolean = currentCall != null
        
        // Get the call state
        fun getCallState(): Int? {
            return currentCall?.details?.state
        }
        
        // Get the phone number of the current call
        fun getPhoneNumber(): String? {
            return currentCall?.details?.handle?.schemeSpecificPart
        }
        
        // Put call on hold
        fun putOnHold() {
            currentCall?.let { call ->
                Log.d(TAG, "Putting call on hold")
                call.hold()
            }
        }
        
        // Unhold the call
        fun unhold() {
            currentCall?.let { call ->
                Log.d(TAG, "Unholding call")
                call.unhold()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        Log.d(TAG, "CallService created")
    }

    override fun onDestroy() {
        instance = null
        currentCall = null
        Log.d(TAG, "CallService destroyed")
        super.onDestroy()
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        Log.d(TAG, "Call added: ${call.details.handle}")
        
        // Store the current call
        currentCall = call
        
        // Register callback to monitor call state changes
        call.registerCallback(callCallback)
        
        // Launch the Flutter app to show the incoming call UI
        launchFlutterApp(call)
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        Log.d(TAG, "Call removed: ${call.details.handle}")
        
        // Unregister callback
        call.unregisterCallback(callCallback)
        
        // Clear the current call if it matches
        if (currentCall == call) {
            currentCall = null
        }
    }

    private fun launchFlutterApp(call: Call) {
        try {
            // Get phone number from the call
            val phoneNumber = call.details.handle?.schemeSpecificPart ?: "Unknown"
            val isIncoming = call.details.state == Call.STATE_RINGING
            
            Log.d(TAG, "Launching Flutter app for ${if (isIncoming) "incoming" else "outgoing"} call: $phoneNumber")
            
            // Create intent to launch MainActivity
            val intent = Intent(this, MainActivity::class.java).apply {
                // Make it launch in a new task
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                
                // Pass call information to Flutter
                putExtra("action", "incoming_call")
                putExtra("phone_number", phoneNumber)
                putExtra("call_state", call.details.state)
                putExtra("is_incoming", isIncoming)
            }
            
            // Launch the app
            startActivity(intent)
            
        } catch (e: Exception) {
            Log.e(TAG, "Error launching Flutter app", e)
        }
    }

    // Callback to monitor call state changes
    private val callCallback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            super.onStateChanged(call, state)
            
            val stateString = when (state) {
                Call.STATE_NEW -> "NEW"
                Call.STATE_DIALING -> "DIALING"
                Call.STATE_RINGING -> "RINGING"
                Call.STATE_ACTIVE -> "ACTIVE"
                Call.STATE_HOLDING -> "HOLDING"
                Call.STATE_DISCONNECTED -> "DISCONNECTED"
                Call.STATE_CONNECTING -> "CONNECTING"
                Call.STATE_DISCONNECTING -> "DISCONNECTING"
                Call.STATE_SELECT_PHONE_ACCOUNT -> "SELECT_PHONE_ACCOUNT"
                else -> "UNKNOWN"
            }
            
            Log.d(TAG, "Call state changed to: $stateString")
            
            // You can notify Flutter about state changes via MethodChannel here
            // For now, just log the state
            
            when (state) {
                Call.STATE_ACTIVE -> {
                    Log.d(TAG, "Call is now active")
                    // Notify Flutter that call was answered
                }
                Call.STATE_DISCONNECTED -> {
                    Log.d(TAG, "Call disconnected")
                    // Clear the call reference
                    if (currentCall == call) {
                        currentCall = null
                    }
                    // Notify Flutter that call ended
                }
                Call.STATE_RINGING -> {
                    Log.d(TAG, "Incoming call ringing")
                    // Update Flutter UI
                }
            }
        }

        override fun onDetailsChanged(call: Call, details: Call.Details) {
            super.onDetailsChanged(call, details)
            Log.d(TAG, "Call details changed: ${details.handle}")
        }
    }
}