package com.example.pro_dialer

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telecom.TelecomManager
import android.util.Log
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.nighatech.pro_dialer/native_call"
    private val DEFAULT_DIALER_CHANNEL = "com.nighatech.pro_dialer/default_dialer"
    private val CALL_CHANNEL = "com.example.pro_dialer/call" // ✅ NEW: Phase 3 Channel
    private val TAG = "ProDialer"
    
    // Request codes
    private val REQUEST_DEFAULT_DIALER = 1001
    private val REQUEST_ROLE_DIALER = 1002
    
    private var defaultDialerResult: MethodChannel.Result? = null

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        
        // ✅ EXISTING CALL CHANNEL
        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            CHANNEL
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "answerCall" -> {
                    try {
                        CallService.answer()
                        result.success(true)
                    } catch (e: Exception) {
                        Log.e(TAG, "Error answering call", e)
                        result.error("ANSWER_ERROR", "Failed to answer call: ${e.message}", null)
                    }
                }
                
                "endCall" -> {
                    try {
                        CallService.hangup()
                        result.success(true)
                    } catch (e: Exception) {
                        Log.e(TAG, "Error ending call", e)
                        result.error("END_ERROR", "Failed to end call: ${e.message}", null)
                    }
                }
                
                "startCall" -> {
                    try {
                        val phoneNumber = call.argument<String>("phoneNumber")
                        if (phoneNumber.isNullOrEmpty()) {
                            result.error("INVALID_NUMBER", "Phone number is required", null)
                            return@setMethodCallHandler
                        }
                        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phoneNumber"))
                        startActivity(intent)
                        result.success(true)
                    } catch (e: Exception) {
                        Log.e(TAG, "Error starting call", e)
                        result.error("CALL_ERROR", "Failed to start call: ${e.message}", null)
                    }
                }
                
                "setMuted" -> {
                    try {
                        val muted = call.argument<Boolean>("muted") ?: false
                        CallService.setMuted(muted)
                        result.success(true)
                    } catch (e: Exception) {
                        Log.e(TAG, "Error setting mute", e)
                        result.error("MUTE_ERROR", "Failed to set mute: ${e.message}", null)
                    }
                }
                
                else -> {
                    result.notImplemented()
                }
            }
        }
        
        //  NEW DEFAULT DIALER CHANNEL
        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            DEFAULT_DIALER_CHANNEL
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "isDefaultDialer" -> {
                    try {
                        val isDefault = checkIsDefaultDialer()
                        Log.d(TAG, "Is default dialer: $isDefault")
                        result.success(isDefault)
                    } catch (e: Exception) {
                        Log.e(TAG, "Error checking default dialer", e)
                        result.error("CHECK_ERROR", "Failed to check default dialer: ${e.message}", null)
                    }
                }
                
                "requestDefaultDialer" -> {
                    try {
                        defaultDialerResult = result
                        requestDefaultDialerPermission()
                    } catch (e: Exception) {
                        Log.e(TAG, "Error requesting default dialer", e)
                        result.error("REQUEST_ERROR", "Failed to request default dialer: ${e.message}", null)
                    }
                }
                
                else -> {
                    result.notImplemented()
                }
            }
        }
        
        //  PHASE 3: CALL CHANNEL
        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            CALL_CHANNEL
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "startCall" -> {
                    try {
                        val phoneNumber = call.argument<String>("phoneNumber")
                        if (phoneNumber.isNullOrEmpty()) {
                            result.error("INVALID_NUMBER", "Phone number is required", null)
                            return@setMethodCallHandler
                        }
                        Log.d(TAG, "Starting call to: $phoneNumber")
                        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phoneNumber"))
                        startActivity(intent)
                        result.success(true)
                    } catch (e: Exception) {
                        Log.e(TAG, "Error starting call", e)
                        result.error("CALL_ERROR", "Failed to start call: ${e.message}", null)
                    }
                }
                
                else -> {
                    result.notImplemented()
                }
            }
        }
    }

    // ✅ CHECK IF APP IS DEFAULT DIALER
    private fun checkIsDefaultDialer(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+ (API 29) - Use RoleManager
            val roleManager = getSystemService(Context.ROLE_SERVICE) as RoleManager
            roleManager.isRoleHeld(RoleManager.ROLE_DIALER)
        } else {
            // Android 9 and below - Use TelecomManager
            val telecomManager = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            packageName == telecomManager.defaultDialerPackage
        }
    }

    // ✅ REQUEST DEFAULT DIALER PERMISSION
    private fun requestDefaultDialerPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+ (API 29) - Use RoleManager
            val roleManager = getSystemService(Context.ROLE_SERVICE) as RoleManager
            
            if (roleManager.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                if (!roleManager.isRoleHeld(RoleManager.ROLE_DIALER)) {
                    val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER)
                    startActivityForResult(intent, REQUEST_ROLE_DIALER)
                    Log.d(TAG, "Requesting ROLE_DIALER via RoleManager")
                } else {
                    Log.d(TAG, "Already default dialer (RoleManager)")
                    defaultDialerResult?.success(true)
                    defaultDialerResult = null
                }
            } else {
                Log.e(TAG, "ROLE_DIALER not available on this device")
                defaultDialerResult?.error("ROLE_UNAVAILABLE", "Dialer role not available", null)
                defaultDialerResult = null
            }
        } else {
            // Android 9 and below - Use TelecomManager
            val telecomManager = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            
            if (packageName != telecomManager.defaultDialerPackage) {
                val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                intent.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
                startActivityForResult(intent, REQUEST_DEFAULT_DIALER)
                Log.d(TAG, "Requesting default dialer via TelecomManager")
            } else {
                Log.d(TAG, "Already default dialer (TelecomManager)")
                defaultDialerResult?.success(true)
                defaultDialerResult = null
            }
        }
    }

    // ✅ HANDLE RESULT FROM SYSTEM DIALOGS
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        when (requestCode) {
            REQUEST_ROLE_DIALER, REQUEST_DEFAULT_DIALER -> {
                // Check if app is now the default dialer
                val isNowDefault = checkIsDefaultDialer()
                Log.d(TAG, "Default dialer request result - Is default: $isNowDefault")
                
                defaultDialerResult?.success(isNowDefault)
                defaultDialerResult = null
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIncomingCall(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingCall(intent)
    }

    private fun handleIncomingCall(intent: Intent?) {
        if (intent?.action == Intent.ACTION_ANSWER) {
            // Handle incoming call
            Log.d(TAG, "Incoming call detected")
        }
    }
}
